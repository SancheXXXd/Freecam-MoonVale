# Freecam (MoonVale)

Client-side Freecam mod for the MoonVale server.

Version: `1.0.0+26.2`

This archive contains a reconstructed source tree and the mod resources. It was prepared from the compiled mod artifact and may need project-specific Gradle configuration before rebuilding.

## Authors

- SancheXXXd_
- Omeleox
