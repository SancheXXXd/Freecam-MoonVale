package net.xolt.freecam.util;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.ModConfig;
import net.xolt.freecam.config.model.Perspective;
import net.xolt.freecam.util.FreecamPosition;
import net.xolt.freecam.util.Motion;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Vector3f;

@ApiStatus.Internal
@ApiStatus.AvailableSince(value="0.4.0")
public class FreeCamera
extends AbstractClientPlayer {
    private static final double MAX_PLAYER_DISTANCE = 32.0;
    private static final double SOFT_BOUNDARY_DISTANCE = 26.0;
    private static final double SOFT_BOUNDARY_WIDTH = 6.0;
    private final Vector3f boundaryContactNormal = new Vector3f(1.0f, 0.0f, 0.0f);
    private float boundaryGlow;
    public ClientInput input;
    public float yBob;
    public float xBob;
    public float yBobO;
    public float xBobO;

    public FreeCamera(int id) {
        super(Freecam.MC.level, new GameProfile(UUID.randomUUID(), "FreeCamera"));
        this.setId(id);
        this.setPose(Pose.SWIMMING);
        this.getAbilities().flying = true;
        this.input = new KeyboardInput(Freecam.MC.options);
    }

    public void tick() {
        this.input.tick();
        this.doMotion();
        this.applyBoundaryResistance();
        super.tick();
        this.enforcePlayerRadius();
        this.updateBoundaryGlow();
    }

    public void copyPosition(Entity entity) {
        this.applyPosition(new FreecamPosition(entity));
        this.enforcePlayerRadius();
    }

    public void applyPosition(FreecamPosition position) {
        this.snapTo(position.x, position.y, position.z, position.yaw, position.pitch);
        this.xBob = this.getXRot();
        this.yBob = this.getYRot();
        this.xBobO = this.xBob;
        this.yBobO = this.yBob;
    }

    public void applyPerspective(Perspective perspective) {
        FreecamPosition position = new FreecamPosition((Entity)this);
        switch (perspective) {
            case INSIDE: {
                break;
            }
            case FIRST_PERSON: {
                this.moveForwardUntilCollision(position, 0.4);
                break;
            }
            case THIRD_PERSON_MIRROR: {
                position.mirrorRotation();
            }
            case THIRD_PERSON: {
                this.moveForwardUntilCollision(position, -4.0);
            }
        }
    }

    private boolean moveForwardUntilCollision(FreecamPosition position, double maxDistance) {
        boolean negative = maxDistance < 0.0;
        maxDistance = negative ? -1.0 * maxDistance : maxDistance;
        double increment = 0.1;
        for (double distance = 0.0; distance < maxDistance; distance += increment) {
            FreecamPosition oldPosition = new FreecamPosition((Entity)this);
            position.moveForward(negative ? -1.0 * increment : increment);
            this.applyPosition(position);
            if (this.wouldNotSuffocateAtTargetPose(this.getPose())) continue;
            this.applyPosition(oldPosition);
            return distance > 0.0;
        }
        return true;
    }

    private ClientLevel getClientLevel() {
        return (ClientLevel)this.level();
    }

    public void spawn() {
        this.getClientLevel().addEntity((Entity)this);
    }

    public void despawn() {
        this.getClientLevel().removeEntity(this.getId(), Entity.RemovalReason.DISCARDED);
    }

    protected void checkFallDamage(double heightDifference, boolean onGround, BlockState landedState, BlockPos landedPosition) {
    }

    public float getAttackAnim(float tickDelta) {
        return Freecam.MC.player.getAttackAnim(tickDelta);
    }

    public int getUseItemRemainingTicks() {
        return Freecam.MC.player.getUseItemRemainingTicks();
    }

    public boolean isUsingItem() {
        return Freecam.MC.player.isUsingItem();
    }

    public boolean onClimbable() {
        return false;
    }

    public boolean isInWater() {
        return false;
    }

    public MobEffectInstance getEffect(Holder<MobEffect> effect) {
        return Freecam.MC.player.getEffect(effect);
    }

    public PushReaction getPistonPushReaction() {
        return PushReaction.NORMAL;
    }

    public boolean canCollideWith(Entity other) {
        return true;
    }

    public void setPose(Pose pose) {
        super.setPose(Pose.SWIMMING);
    }

    protected boolean updateIsUnderwater() {
        this.wasUnderwater = this.isEyeInFluid(FluidTags.WATER);
        return this.wasUnderwater;
    }

    protected void doWaterSplashEffect() {
    }

    private void doMotion() {
        switch (ModConfig.get().getFlightMode()) {
            case DEFAULT: {
                this.getAbilities().setFlyingSpeed(0.0f);
                Motion.doMotion(this, ModConfig.get().getHorizontalSpeed(), ModConfig.get().getVerticalSpeed());
                break;
            }
            case CREATIVE: {
                this.getAbilities().setFlyingSpeed((float)ModConfig.get().getVerticalSpeed() / 10.0f);
                if (!(this.input.keyPresses.shift() ^ this.input.keyPresses.jump())) break;
                int direction = this.input.keyPresses.jump() ? 1 : -1;
                this.setDeltaMovement(this.getDeltaMovement().add(0.0, (double)((float)direction * this.getAbilities().getFlyingSpeed() * 3.0f), 0.0));
            }
        }
        this.getAbilities().flying = true;
        this.setOnGround(false);
    }

    public void enforcePlayerRadius() {
        double maxDistanceSquared;
        double dz;
        double dy;
        if (Freecam.MC.player == null) {
            return;
        }
        double dx = this.getX() - Freecam.MC.player.getX();
        double distanceSquared = dx * dx + (dy = this.getY() - Freecam.MC.player.getEyeY()) * dy + (dz = this.getZ() - Freecam.MC.player.getZ()) * dz;
        if (distanceSquared <= (maxDistanceSquared = 1024.0)) {
            return;
        }
        double scale = 32.0 / Math.sqrt(distanceSquared);
        this.boundaryContactNormal.set((float)(dx / Math.sqrt(distanceSquared)), (float)(dy / Math.sqrt(distanceSquared)), (float)(dz / Math.sqrt(distanceSquared)));
        this.snapTo(Freecam.MC.player.getX() + dx * scale, Freecam.MC.player.getEyeY() + dy * scale, Freecam.MC.player.getZ() + dz * scale, this.getYRot(), this.getXRot());
    }

    private void applyBoundaryResistance() {
        double dz;
        double dy;
        if (Freecam.MC.player == null) {
            return;
        }
        double dx = this.getX() - Freecam.MC.player.getX();
        double distance = Math.sqrt(dx * dx + (dy = this.getY() - Freecam.MC.player.getEyeY()) * dy + (dz = this.getZ() - Freecam.MC.player.getZ()) * dz);
        if (distance <= 26.0 || distance == 0.0) {
            return;
        }
        double nx = dx / distance;
        double ny = dy / distance;
        double nz = dz / distance;
        Vec3 velocity = this.getDeltaMovement();
        double outwardVelocity = velocity.x * nx + velocity.y * ny + velocity.z * nz;
        double pressure = Math.min(1.0, (distance - 26.0) / 6.0);
        if (outwardVelocity > 0.0) {
            double damping = pressure * pressure * 0.92;
            velocity = velocity.subtract(nx * outwardVelocity * damping, ny * outwardVelocity * damping, nz * outwardVelocity * damping);
        }
        double spring = pressure * pressure * 0.045;
        this.setDeltaMovement(velocity.subtract(nx * spring, ny * spring, nz * spring));
        this.boundaryContactNormal.set((float)nx, (float)ny, (float)nz);
    }

    private void updateBoundaryGlow() {
        if (Freecam.MC.player == null) {
            this.boundaryGlow = 0.0f;
            return;
        }
        double dx = this.getX() - Freecam.MC.player.getX();
        double dy = this.getY() - Freecam.MC.player.getEyeY();
        double dz = this.getZ() - Freecam.MC.player.getZ();
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        float target = (float)Math.max(0.0, Math.min(1.0, (distance - 26.0) / 6.0));
        this.boundaryGlow += (target - this.boundaryGlow) * 0.18f;
    }

    public float getBoundaryGlow() {
        return this.boundaryGlow;
    }

    public Vector3f getBoundaryContactNormal() {
        return this.boundaryContactNormal;
    }

    public float getViewXRot(float partialTick) {
        return this.getXRot();
    }

    public float getViewYRot(float partialTick) {
        return this.getYRot();
    }

    public boolean isEffectiveAi() {
        return true;
    }

    public boolean canSimulateMovement() {
        return true;
    }

    protected void applyInput() {
        Vec2 vec2 = this.input.getMoveVector();
        if (vec2.lengthSquared() != 0.0f) {
            vec2 = vec2.scale(0.98f);
        }
        this.applyInputHelper(vec2, this.input.keyPresses.jump());
    }

    private void applyInputHelper(Vec2 moveVector, boolean jumping) {
        this.xxa = moveVector.x;
        this.zza = moveVector.y;
        this.jumping = jumping;
        this.setSprinting(Freecam.MC.options.keySprint.isDown() && this.input.keyPresses.forward() || this.input.keyPresses.forward() && this.isSprinting());
        this.yBobO = this.yBob;
        this.xBobO = this.xBob;
        this.xBob += (this.getXRot() - this.xBob) * 0.5f;
        this.yBob += (this.getYRot() - this.yBob) * 0.5f;
    }
}

