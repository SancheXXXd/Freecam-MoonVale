package net.xolt.freecam.fabric.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets={"net.xolt.freecam.fabric.BoundaryRenderer"}, remap=false)
public abstract class SquareBoundaryRenderMixin {
    public SquareBoundaryRenderMixin() {
        super();
    }

    @Inject(method={"drawBoundary"}, at=@At(value="HEAD"), cancellable=true, remap=false)
    private static void freecam$drawSquare(PoseStack.Pose pose, VertexConsumer vertexConsumer, Vector3f vector3f, float f, float f2, CallbackInfo callbackInfo) {
        double d = -32.0;
        double d2 = 32.0;
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d, d, d2, d, d, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d2, d, d2, d2, d, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d, d2, d2, d, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d2, d2, d2, d2, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d, d, d, d2, d, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d2, d, d, d2, d2, d, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d, d2, d, d2, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d2, d, d2, d2, d2, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d, d, d, d, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d2, d, d, d2, d, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d, d2, d, d, d2, d2, vector3f, f, f2);
        SquareBoundaryRenderMixin.edge(pose, vertexConsumer, d2, d2, d, d2, d2, d2, vector3f, f, f2);
        callbackInfo.cancel();
    }

    private static void edge(PoseStack.Pose pose, VertexConsumer vertexConsumer, double d, double d2, double d3, double d4, double d5, double d6, Vector3f vector3f, float f, float f2) {
        float f3 = (float)(d4 - d);
        float f4 = (float)(d5 - d2);
        float f5 = (float)(d6 - d3);
        float f6 = (float)Math.sqrt(f3 * f3 + f4 * f4 + f5 * f5);
        if (f6 > 0.0f) {
            f3 /= f6;
            f4 /= f6;
            f5 /= f6;
        }
        SquareBoundaryRenderMixin.vertex(pose, vertexConsumer, d, d2, d3, f3, f4, f5, vector3f, f, f2);
        SquareBoundaryRenderMixin.vertex(pose, vertexConsumer, d4, d5, d6, f3, f4, f5, vector3f, f, f2);
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer vertexConsumer, double d, double d2, double d3, float f, float f2, float f3, Vector3f vector3f, float f4, float f5) {
        double d4 = Math.sqrt(d * d + d2 * d2 + d3 * d3);
        double d5 = d4 == 0.0 ? 0.0 : Math.max(0.0, d / d4 * (double)vector3f.x() + d2 / d4 * (double)vector3f.y() + d3 / d4 * (double)vector3f.z());
        float f6 = (float)(0.5 + 0.5 * Math.cos((1.0 - d5) * Math.PI * 2.0 - (double)f5));
        float f7 = Math.min(1.0f, 0.15f + 0.85f * f6);
        float f8 = Math.min(0.9f, f4 * (0.22f + 0.68f * f7));
        int n = SquareBoundaryRenderMixin.mix(57, 169, f7);
        int n2 = SquareBoundaryRenderMixin.mix(125, 208, f7);
        int n3 = SquareBoundaryRenderMixin.mix(236, 252, f7);
        vertexConsumer.addVertex(pose, (float)d, (float)d2, (float)d3).setColor(n, n2, n3, (int)(f8 * 255.0f)).setNormal(pose, f, f2, f3).setLineWidth(2.5f);
    }

    private static int mix(int n, int n2, float f) {
        return Math.round((float)n + (float)(n2 - n) * f);
    }
}

