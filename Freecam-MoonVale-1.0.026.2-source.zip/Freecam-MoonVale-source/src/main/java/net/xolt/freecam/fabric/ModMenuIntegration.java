package net.xolt.freecam.fabric;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.xolt.freecam.config.gui.ConfigScreenProvider;

@Environment(value=EnvType.CLIENT)
public class ModMenuIntegration
implements ModMenuApi {
    public ModMenuIntegration() {
        super();
    }

    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ConfigScreenProvider.provider()::getConfigScreen;
    }
}

