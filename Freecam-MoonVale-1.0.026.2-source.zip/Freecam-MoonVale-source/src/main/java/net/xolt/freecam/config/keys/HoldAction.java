package net.xolt.freecam.config.keys;

@FunctionalInterface
public interface HoldAction {
    public boolean run();
}

