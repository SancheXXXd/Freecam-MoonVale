package net.xolt.freecam.config.gui;

import java.util.Collection;
import java.util.Objects;
import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.minecraft.client.gui.screens.Screen;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.gui.FallbackConfigScreenProvider;
import net.xolt.freecam.config.gui.OptionalProvider;
import net.xolt.freecam.util.MultiServiceLoader;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface ConfigScreenProvider {
    public String getName();

    public Screen getConfigScreen(Screen var1);

    default public void openConfigScreen() {
        this.openConfigScreen(Freecam.MC.gui.screen());
    }

    default public void openConfigScreen(Screen parent) {
        Freecam.MC.gui.setScreen(this.getConfigScreen(parent));
    }

    public static ConfigScreenProvider provider() {
        return Holder.INSTANCE;
    }

    public static final class Holder {
        private static final Logger LOGGER = LoggerFactory.getLogger(ConfigScreenProvider.class);
        private static final ConfigScreenProvider INSTANCE;

        private Holder() {
            super();
        }

        @Nullable
        private static ConfigScreenProvider attemptLoad(ServiceLoader.Provider<ConfigScreenProvider> provider) {
            try {
                return provider.get();
            }
            catch (Throwable t) {
                LOGGER.error("{} provider {} failed to load", new Object[]{ConfigScreenProvider.class.getSimpleName(), provider.type().getSimpleName(), t});
                return null;
            }
        }

        static {
            Collection<ServiceLoader.Provider<ConfigScreenProvider>> providers = MultiServiceLoader.get(ConfigScreenProvider.class);
            LOGGER.debug("Loaded: {}", (Object)providers.stream().map(provider -> provider.type().getSimpleName()).collect(Collectors.joining(", ")));
            INSTANCE = providers.stream().map(Holder::attemptLoad).filter(Objects::nonNull).filter(provider -> {
                OptionalProvider optional;
                return !(provider instanceof OptionalProvider) || (optional = (OptionalProvider)((Object)provider)).isAvailable();
            }).findFirst().orElseGet(FallbackConfigScreenProvider::new);
            LOGGER.info("Using {}", (Object)INSTANCE.getName());
        }
    }
}

