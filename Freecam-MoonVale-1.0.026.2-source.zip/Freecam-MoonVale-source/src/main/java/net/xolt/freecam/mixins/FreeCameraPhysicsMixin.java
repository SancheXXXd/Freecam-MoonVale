package net.xolt.freecam.mixins;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.material.PushReaction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets={"net.xolt.freecam.util.FreeCamera"}, remap=false)
public abstract class FreeCameraPhysicsMixin {
    public FreeCameraPhysicsMixin() {
        super();
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")}, remap=false)
    private void freecam$enableNoClip(CallbackInfo ci) {
        ((Entity)this).noPhysics = true;
    }

    @Inject(method={"canCollideWith"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void freecam$disableEntityCollision(Entity other, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue((Object)Boolean.FALSE);
    }

    @Inject(method={"getPistonPushReaction"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void freecam$ignorePistons(CallbackInfoReturnable<PushReaction> cir) {
        cir.setReturnValue((Object)PushReaction.IGNORE);
    }
}

