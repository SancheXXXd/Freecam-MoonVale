package net.xolt.freecam.config.gui;

public interface OptionalProvider {
    public boolean isAvailable();
}

