package net.xolt.freecam.mixins;

import net.minecraft.client.renderer.GameRenderer;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.ModConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GameRenderer.class})
public class GameRendererMixin {
    public GameRendererMixin() {
        super();
    }

    @Inject(method={"renderItemInHand"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderItemInHand(CallbackInfo ci) {
        if (Freecam.isEnabled() && ModConfig.get().shouldHideHand()) {
            ci.cancel();
        }
    }
}

