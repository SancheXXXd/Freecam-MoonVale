package net.xolt.freecam.config.keys;

@FunctionalInterface
public interface Tickable {
    public void tick();
}

