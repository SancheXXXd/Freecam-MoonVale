package net.xolt.freecam.mixins;

import net.minecraft.client.Camera;
import net.minecraft.world.phys.Vec3;
import net.xolt.freecam.Freecam;
import org.lwjgl.openal.AL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets={"su.plo.voice.client.audio.device.AlOutputDevice$AlListener"}, remap=false)
public class PlasmoVoiceListenerMixin {
    private static final int AL_GAIN = 4106;

    public PlasmoVoiceListenerMixin() {
        super();
    }

    @Redirect(method={"update"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/Camera;position()Lnet/minecraft/world/phys/Vec3;", remap=true), remap=false)
    private Vec3 freecam$playerPosition(Camera camera) {
        return Freecam.isEnabled() && Freecam.MC.player != null ? Freecam.MC.player.getEyePosition() : camera.position();
    }

    @Inject(method={"update"}, at={@At(value="HEAD")}, remap=false)
    private void freecam$syncVoiceOutputGain(CallbackInfo ci) {
        AL11.alListenerf((int)4106, (float)(Freecam.isEnabled() ? 0.0f : 1.0f));
    }
}

