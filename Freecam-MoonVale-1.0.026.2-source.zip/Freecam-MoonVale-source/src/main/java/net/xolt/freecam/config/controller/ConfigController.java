package net.xolt.freecam.config.controller;

public interface ConfigController<T> {
    public T getConfig();

    public T getDefaults();

    public void load();

    public void save();

    public void registerListener(Runnable var1);
}

