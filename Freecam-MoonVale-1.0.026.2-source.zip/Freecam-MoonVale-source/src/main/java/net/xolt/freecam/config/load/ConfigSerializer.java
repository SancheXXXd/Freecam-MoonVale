package net.xolt.freecam.config.load;

import java.io.Reader;
import java.io.Writer;

public interface ConfigSerializer<N> {
    public N parse(Reader var1) throws Exception;

    public void write(N var1, Writer var2) throws Exception;

    public <T> T deserialize(N var1, Class<T> var2);

    public <T> N serialize(T var1);
}

