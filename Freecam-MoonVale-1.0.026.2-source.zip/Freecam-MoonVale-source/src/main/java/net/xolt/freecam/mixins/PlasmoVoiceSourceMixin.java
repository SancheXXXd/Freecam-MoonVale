package net.xolt.freecam.mixins;

import net.xolt.freecam.Freecam;
import org.lwjgl.openal.AL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Pseudo
@Mixin(targets={"su.plo.voice.client.audio.device.source.BaseAlSource"}, remap=false)
public class PlasmoVoiceSourceMixin {
    private static final int AL_GAIN = 4106;

    public PlasmoVoiceSourceMixin() {
        super();
    }

    @Redirect(method={"setFloat"}, at=@At(value="INVOKE", target="Lorg/lwjgl/openal/AL11;alSourcef(IIF)V", remap=false), remap=false)
    private void freecam$muteVoiceSource(int source, int parameter, float value) {
        AL11.alSourcef((int)source, (int)parameter, (float)(parameter == 4106 && Freecam.isEnabled() ? 0.0f : value));
    }
}

