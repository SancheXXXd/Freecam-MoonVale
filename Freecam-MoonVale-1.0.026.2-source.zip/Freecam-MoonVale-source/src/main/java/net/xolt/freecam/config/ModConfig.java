package net.xolt.freecam.config;

import com.google.gson.JsonObject;
import java.nio.file.Path;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.controller.BasicConfigController;
import net.xolt.freecam.config.controller.ConfigControllerRegistry;
import net.xolt.freecam.config.controller.ModConfigController;
import net.xolt.freecam.config.load.ModConfigLoader;
import net.xolt.freecam.config.load.RawJsonPreservingSerializer;
import net.xolt.freecam.config.model.FlightMode;
import net.xolt.freecam.config.model.ModConfigDTO;
import net.xolt.freecam.config.model.ModConfigImpl;
import net.xolt.freecam.config.model.Perspective;

public interface ModConfig {
    public static void setup() {
        Path configDir = Freecam.MC.gameDirectory.toPath().resolve("config");
        RawJsonPreservingSerializer serializer = new RawJsonPreservingSerializer();
        ModConfigLoader loader = new ModConfigLoader(serializer, "freecam", configDir);
        BasicConfigController<ModConfigDTO> dtoController = new BasicConfigController<ModConfigDTO>(loader, ModConfigDTO::new);
        ConfigControllerRegistry.register(ModConfigDTO.class, dtoController);
        ModConfigController controller = new ModConfigController(dtoController);
        ConfigControllerRegistry.register(ModConfigImpl.class, controller);
        controller.load();
        ModConfig.removeRetiredOptions((ModConfigDTO)dtoController.getConfig());
    }

    public static ModConfig get() {
        return ConfigControllerRegistry.get(ModConfigImpl.class).getConfig();
    }

    private static void removeRetiredOptions(ModConfigDTO config) {
        JsonObject raw = config.getRawJson();
        if (raw == null) {
            return;
        }
        ModConfig.removeChild(raw, "visual", "outlinePlayer");
        ModConfig.removeChild(raw, "visual", "showSubmersion");
        ModConfig.removeChild(raw, "utility", "freezePlayer");
        ModConfig.removeChild(raw, "utility", "allowInteract");
        ModConfig.removeChild(raw, "utility", "interactionMode");
        raw.remove("servers");
    }

    private static void removeChild(JsonObject root, String section, String option) {
        if (root.has(section) && root.get(section).isJsonObject()) {
            root.getAsJsonObject(section).remove(option);
        }
    }

    public FlightMode getFlightMode();

    public double getHorizontalSpeed();

    public double getVerticalSpeed();

    public Perspective getInitialPerspective();

    public boolean shouldShowPlayer();

    default public boolean shouldHidePlayer() {
        return !this.shouldShowPlayer();
    }

    public boolean shouldShowHand();

    default public boolean shouldHideHand() {
        return !this.shouldShowHand();
    }

    public boolean isFullBrightEnabled();

    public boolean shouldDisableOnDamage();

    public boolean shouldNotifyFreecam();

    public boolean shouldNotifyTripod();
}

