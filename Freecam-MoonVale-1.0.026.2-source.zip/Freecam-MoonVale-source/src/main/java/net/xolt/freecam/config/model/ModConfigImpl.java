package net.xolt.freecam.config.model;

import net.xolt.freecam.config.ModConfig;
import net.xolt.freecam.config.model.FlightMode;
import net.xolt.freecam.config.model.ModConfigDTO;
import net.xolt.freecam.config.model.Perspective;

public class ModConfigImpl
implements ModConfig {
    private final ModConfigDTO data;

    public ModConfigImpl(ModConfigDTO data) {
        super();
        this.data = data;
    }

    public ModConfigDTO getData() {
        return this.data;
    }

    @Override
    public FlightMode getFlightMode() {
        return this.data.movement.flightMode;
    }

    @Override
    public double getHorizontalSpeed() {
        return this.data.movement.horizontalSpeed;
    }

    @Override
    public double getVerticalSpeed() {
        return this.data.movement.verticalSpeed;
    }

    @Override
    public Perspective getInitialPerspective() {
        return this.data.visual.perspective;
    }

    @Override
    public boolean shouldShowPlayer() {
        return this.data.visual.showPlayer;
    }

    @Override
    public boolean shouldShowHand() {
        return this.data.visual.showHand;
    }

    @Override
    public boolean isFullBrightEnabled() {
        return this.data.visual.fullBright;
    }

    @Override
    public boolean shouldDisableOnDamage() {
        return this.data.utility.disableOnDamage;
    }

    @Override
    public boolean shouldNotifyFreecam() {
        return this.data.notification.notifyFreecam;
    }

    @Override
    public boolean shouldNotifyTripod() {
        return this.data.notification.notifyTripod;
    }
}

