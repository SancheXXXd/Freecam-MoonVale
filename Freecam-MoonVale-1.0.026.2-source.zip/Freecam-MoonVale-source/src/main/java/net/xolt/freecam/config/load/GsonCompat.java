package net.xolt.freecam.config.load;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.jetbrains.annotations.Nullable;

final class GsonCompat {
    private static final Method PARSE_READER = GsonCompat.setupParseReader();
    private static final Method DEEP_COPY = GsonCompat.setupDeepCopy();
    private static Gson gsonInstance = null;

    private GsonCompat() {
        super();
    }

    public static JsonElement parse(Reader reader) throws JsonIOException, JsonSyntaxException {
        if (PARSE_READER != null) {
            try {
                return (JsonElement)PARSE_READER.invoke(null, reader);
            }
            catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException("Failed to invoke JsonParser.parseReader", e);
            }
        }
        Gson gson = GsonCompat.getGson();
        return (JsonElement)gson.fromJson(reader, JsonElement.class);
    }

    public static <T extends JsonElement> T deepCopy(T element) {
        if (DEEP_COPY != null) {
            try {
                return (T)((JsonElement)DEEP_COPY.invoke(element, new Object[0]));
            }
            catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException("Failed to invoke JsonElement.deepCopy", e);
            }
        }
        Gson gson = GsonCompat.getGson();
        return (T)((JsonElement)gson.fromJson(gson.toJson(element), JsonElement.class));
    }

    private static Gson getGson() {
        if (gsonInstance == null) {
            gsonInstance = new Gson();
        }
        return gsonInstance;
    }

    @Nullable
    private static Method setupParseReader() {
        try {
            return JsonParser.class.getMethod("parseReader", Reader.class);
        }
        catch (NoSuchMethodException ignored) {
            return null;
        }
    }

    @Nullable
    private static Method setupDeepCopy() {
        try {
            return JsonElement.class.getMethod("deepCopy", new Class[0]);
        }
        catch (NoSuchMethodException ignored) {
            return null;
        }
    }
}

