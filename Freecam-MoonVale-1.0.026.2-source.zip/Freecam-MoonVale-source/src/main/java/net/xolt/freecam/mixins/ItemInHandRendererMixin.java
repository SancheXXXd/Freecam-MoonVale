package net.xolt.freecam.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.entity.Entity;
import net.xolt.freecam.Freecam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ItemInHandRenderer.class})
public class ItemInHandRendererMixin {
    @Unique
    private float freecam$tickDelta;

    public ItemInHandRendererMixin() {
        super();
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/player/LocalPlayer;getViewXRot(F)F"))
    private float redirectGetViewXRot(LocalPlayer player, float partialTick) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().getViewXRot(partialTick) : player.getViewXRot(partialTick);
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/player/LocalPlayer;getViewYRot(F)F"))
    private float redirectGetViewYRot(LocalPlayer player, float partialTick) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().getViewYRot(partialTick) : player.getViewYRot(partialTick);
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="FIELD", target="Lnet/minecraft/client/player/LocalPlayer;xBob:F", opcode=180))
    private float redirectGetXBob(LocalPlayer player) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().xBob : player.xBob;
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="FIELD", target="Lnet/minecraft/client/player/LocalPlayer;xBobO:F", opcode=180))
    private float redirectGetXBobO(LocalPlayer player) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().xBobO : player.xBobO;
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="FIELD", target="Lnet/minecraft/client/player/LocalPlayer;yBob:F", opcode=180))
    private float redirectGetYBob(LocalPlayer player) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().yBob : player.yBob;
    }

    @Redirect(method={"submitHandsWithItems"}, at=@At(value="FIELD", target="Lnet/minecraft/client/player/LocalPlayer;yBobO:F", opcode=180))
    private float redirectGetYBobO(LocalPlayer player) {
        return Freecam.isEnabled() ? Freecam.getFreeCamera().yBobO : player.yBobO;
    }

    @Inject(method={"submitHandsWithItems"}, at={@At(value="HEAD")})
    private void storeTickDelta(float partialTick, PoseStack poseStack, SubmitNodeCollector nodeCollector, LocalPlayer player, int packedLight, CallbackInfo ci) {
        this.freecam$tickDelta = partialTick;
    }

    @ModifyVariable(method={"submitHandsWithItems"}, at=@At(value="HEAD"), argsOnly=true)
    private int onRenderItemSetLight(int lightCoords) {
        if (Freecam.isEnabled()) {
            return Freecam.MC.getEntityRenderDispatcher().getPackedLightCoords((Entity)Freecam.getFreeCamera(), this.freecam$tickDelta);
        }
        return lightCoords;
    }
}

