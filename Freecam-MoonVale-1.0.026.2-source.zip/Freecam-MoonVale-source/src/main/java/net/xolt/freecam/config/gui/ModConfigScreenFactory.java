package net.xolt.freecam.config.gui;

import java.util.stream.Stream;
import me.shedaniel.clothconfig2.api.AbstractConfigListEntry;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import me.shedaniel.clothconfig2.gui.entries.BooleanListEntry;
import me.shedaniel.clothconfig2.gui.entries.EnumListEntry;
import me.shedaniel.clothconfig2.gui.entries.LongSliderEntry;
import me.shedaniel.clothconfig2.gui.entries.SubCategoryListEntry;
import me.shedaniel.clothconfig2.impl.builders.KeyCodeBuilder;
import me.shedaniel.clothconfig2.impl.builders.SubCategoryBuilder;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.xolt.freecam.config.ModBindings;
import net.xolt.freecam.config.controller.ConfigController;
import net.xolt.freecam.config.model.FlightMode;
import net.xolt.freecam.config.model.ModConfigDTO;
import net.xolt.freecam.config.model.Perspective;

public class ModConfigScreenFactory {
    private static final double SLIDER_SCALE = 100.0;
    private static final double MIN_SPEED = 0.0;
    private static final double MAX_SPEED = 10.0;
    private final ConfigController<ModConfigDTO> controller;

    public ModConfigScreenFactory(ConfigController<ModConfigDTO> controller) {
        super();
        this.controller = controller;
    }

    public Screen getConfigScreen(Screen parent) {
        return this.builder().setParentScreen(parent).build();
    }

    private ModConfigDTO config() {
        return this.controller.getConfig();
    }

    private ModConfigDTO defaults() {
        return this.controller.getDefaults();
    }

    private ConfigBuilder builder() {
        ConfigBuilder builder = ConfigBuilder.create().setTitle((Component)Component.translatable((String)"freecam.config.gui.title")).transparentBackground().setSavingRunnable(this.controller::save);
        ConfigEntryBuilder entryBuilder = builder.entryBuilder();
        ConfigCategory category = this.defaultCategory(builder, entryBuilder);
        return builder;
    }

    private ConfigCategory defaultCategory(ConfigBuilder configBuilder, ConfigEntryBuilder entryBuilder) {
        ConfigCategory category = configBuilder.getOrCreateCategory((Component)Component.empty());
        Stream.of(ModConfigScreenFactory.controlsCategory(entryBuilder), this.movementCategory(entryBuilder), this.visualCategory(entryBuilder), this.utilityCategory(entryBuilder), this.notificationCategory(entryBuilder)).forEach(arg_0 -> ((ConfigCategory)category).addEntry(arg_0));
        return category;
    }

    private static SubCategoryListEntry controlsCategory(ConfigEntryBuilder entryBuilder) {
        SubCategoryBuilder builder = entryBuilder.startSubCategory((Component)Component.translatable((String)"freecam.config.controls.label")).setTooltip(new Component[]{Component.translatable((String)"freecam.config.controls.tooltip")});
        ModBindings.stream().map(bind -> entryBuilder.fillKeybindingField((Component)Component.translatable((String)bind.getName()), (KeyMapping)bind)).map(KeyCodeBuilder::build).forEach(arg_0 -> ((SubCategoryBuilder)builder).add(arg_0));
        return builder.build();
    }

    private SubCategoryListEntry movementCategory(ConfigEntryBuilder entryBuilder) {
        SubCategoryBuilder builder = entryBuilder.startSubCategory((Component)Component.translatable((String)"freecam.config.movement.label")).setTooltip(new Component[]{Component.translatable((String)"freecam.config.movement.tooltip")});
        EnumListEntry flightMode = entryBuilder.startEnumSelector((Component)Component.translatable((String)"freecam.config.movement.flightMode.label"), FlightMode.class, (Enum)this.config().movement.flightMode).setEnumNameProvider(value -> Component.translatable((String)("freecam.config.movement.flightMode." + value.name()))).setTooltip(new Component[]{Component.translatable((String)"freecam.config.movement.flightMode.tooltip")}).setDefaultValue((Enum)this.defaults().movement.flightMode).setSaveConsumer(value -> {
            this.config().movement.flightMode = value;
        }).build();
        LongSliderEntry horizontalSpeed = entryBuilder.startLongSlider((Component)Component.translatable((String)"freecam.config.movement.speed.horizontal.label"), ModConfigScreenFactory.toSlider(this.config().movement.horizontalSpeed), ModConfigScreenFactory.toSlider(0.0), ModConfigScreenFactory.toSlider(10.0)).setDefaultValue(() -> ModConfigScreenFactory.toSlider(this.defaults().movement.horizontalSpeed)).setSaveConsumer(value -> {
            this.config().movement.horizontalSpeed = ModConfigScreenFactory.fromSlider(value);
        }).setTextGetter(value -> Component.translatable((String)"freecam.config.movement.speed.value", (Object[])new Object[]{ModConfigScreenFactory.fromSlider(value)})).setTooltip(new Component[]{Component.translatable((String)"freecam.config.movement.speed.horizontal.tooltip")}).build();
        LongSliderEntry verticalSpeed = entryBuilder.startLongSlider((Component)Component.translatable((String)"freecam.config.movement.speed.vertical.label"), ModConfigScreenFactory.toSlider(this.config().movement.verticalSpeed), ModConfigScreenFactory.toSlider(0.0), ModConfigScreenFactory.toSlider(10.0)).setDefaultValue(() -> ModConfigScreenFactory.toSlider(this.defaults().movement.verticalSpeed)).setSaveConsumer(value -> {
            this.config().movement.verticalSpeed = ModConfigScreenFactory.fromSlider(value);
        }).setTextGetter(value -> Component.translatable((String)"freecam.config.movement.speed.value", (Object[])new Object[]{ModConfigScreenFactory.fromSlider(value)})).setTooltip(new Component[]{Component.translatable((String)"freecam.config.movement.speed.vertical.tooltip")}).build();
        Stream.of(flightMode, horizontalSpeed, verticalSpeed).forEach(arg_0 -> ((SubCategoryBuilder)builder).add(arg_0));
        return builder.build();
    }

    private SubCategoryListEntry visualCategory(ConfigEntryBuilder entryBuilder) {
        SubCategoryBuilder builder = entryBuilder.startSubCategory((Component)Component.translatable((String)"freecam.config.visual.label")).setTooltip(new Component[]{Component.translatable((String)"freecam.config.visual.tooltip")});
        EnumListEntry perspective = entryBuilder.startEnumSelector((Component)Component.translatable((String)"freecam.config.visual.perspective.label"), Perspective.class, (Enum)this.config().visual.perspective).setEnumNameProvider(value -> Component.translatable((String)("freecam.config.visual.perspective." + value.name()))).setTooltip(new Component[]{Component.translatable((String)"freecam.config.visual.perspective.tooltip")}).setDefaultValue((Enum)this.defaults().visual.perspective).setSaveConsumer(value -> {
            this.config().visual.perspective = value;
        }).build();
        BooleanListEntry showPlayer = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.visual.showPlayer.label"), this.config().visual.showPlayer).setTooltip(new Component[]{Component.translatable((String)"freecam.config.visual.showPlayer.tooltip")}).setDefaultValue(this.defaults().visual.showPlayer).setSaveConsumer(value -> {
            this.config().visual.showPlayer = value;
        }).build();
        BooleanListEntry showHand = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.visual.showHand.label"), this.config().visual.showHand).setTooltip(new Component[]{Component.translatable((String)"freecam.config.visual.showHand.tooltip")}).setDefaultValue(this.defaults().visual.showHand).setSaveConsumer(value -> {
            this.config().visual.showHand = value;
        }).build();
        BooleanListEntry fullBright = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.visual.fullBright.label"), this.config().visual.fullBright).setTooltip(new Component[]{Component.translatable((String)"freecam.config.visual.fullBright.tooltip")}).setDefaultValue(this.defaults().visual.fullBright).setSaveConsumer(value -> {
            this.config().visual.fullBright = value;
        }).build();
        Stream.of(perspective, showPlayer, showHand, fullBright).forEach(arg_0 -> ((SubCategoryBuilder)builder).add(arg_0));
        return builder.build();
    }

    private SubCategoryListEntry utilityCategory(ConfigEntryBuilder entryBuilder) {
        SubCategoryBuilder builder = entryBuilder.startSubCategory((Component)Component.translatable((String)"freecam.config.utility.label")).setTooltip(new Component[]{Component.translatable((String)"freecam.config.utility.tooltip")});
        BooleanListEntry disableOnDamage = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.utility.disableOnDamage.label"), this.config().utility.disableOnDamage).setTooltip(new Component[]{Component.translatable((String)"freecam.config.utility.disableOnDamage.tooltip")}).setDefaultValue(this.defaults().utility.disableOnDamage).setSaveConsumer(value -> {
            this.config().utility.disableOnDamage = value;
        }).build();
        builder.add((AbstractConfigListEntry)disableOnDamage);
        return builder.build();
    }

    private SubCategoryListEntry notificationCategory(ConfigEntryBuilder entryBuilder) {
        SubCategoryBuilder builder = entryBuilder.startSubCategory((Component)Component.translatable((String)"freecam.config.notification.label")).setTooltip(new Component[]{Component.translatable((String)"freecam.config.notification.tooltip")});
        BooleanListEntry notifyFreecam = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.notification.freecam.label"), this.config().notification.notifyFreecam).setTooltip(new Component[]{Component.translatable((String)"freecam.config.notification.freecam.tooltip")}).setDefaultValue(this.defaults().notification.notifyFreecam).setSaveConsumer(value -> {
            this.config().notification.notifyFreecam = value;
        }).build();
        BooleanListEntry notifyTripod = entryBuilder.startBooleanToggle((Component)Component.translatable((String)"freecam.config.notification.tripod.label"), this.config().notification.notifyTripod).setTooltip(new Component[]{Component.translatable((String)"freecam.config.notification.tripod.tooltip")}).setDefaultValue(this.defaults().notification.notifyTripod).setSaveConsumer(value -> {
            this.config().notification.notifyTripod = value;
        }).build();
        Stream.of(notifyFreecam, notifyTripod).forEach(arg_0 -> ((SubCategoryBuilder)builder).add(arg_0));
        return builder.build();
    }

    private static long toSlider(double value) {
        return (long)(value * 100.0);
    }

    private static double fromSlider(long value) {
        return (double)value / 100.0;
    }
}

