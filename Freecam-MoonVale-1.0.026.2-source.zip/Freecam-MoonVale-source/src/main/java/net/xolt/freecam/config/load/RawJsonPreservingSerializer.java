package net.xolt.freecam.config.load;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;
import net.xolt.freecam.config.load.ConfigSerializer;
import net.xolt.freecam.config.load.GsonCompat;
import net.xolt.freecam.config.load.GsonSerializer;
import net.xolt.freecam.config.load.RawJsonHolder;

public class RawJsonPreservingSerializer
implements ConfigSerializer<JsonElement> {
    private final ConfigSerializer<JsonElement> delegate;

    public RawJsonPreservingSerializer() {
        this(new GsonSerializer());
    }

    public RawJsonPreservingSerializer(ConfigSerializer<JsonElement> delegate) {
        super();
        this.delegate = delegate;
    }

    @Override
    public <T> T deserialize(JsonElement json, Class<T> configClass) {
        T config = this.delegate.deserialize(json, configClass);
        T t = config;
        if (t instanceof RawJsonHolder) {
            RawJsonHolder holder = (RawJsonHolder)t;
            if (json.isJsonObject()) {
                holder.setRawJson(json.getAsJsonObject());
            }
        }
        return config;
    }

    @Override
    public <T> JsonElement serialize(T config) {
        RawJsonHolder holder;
        JsonObject previous;
        JsonElement current = this.delegate.serialize(config);
        T t = config;
        if (t instanceof RawJsonHolder && (previous = (holder = (RawJsonHolder)t).getRawJson()) != null) {
            return this.merge(current, (JsonElement)previous);
        }
        return current;
    }

    @Override
    public JsonElement parse(Reader reader) throws Exception {
        return this.delegate.parse(reader);
    }

    @Override
    public void write(JsonElement json, Writer writer) throws Exception {
        this.delegate.write(json, writer);
    }

    JsonElement merge(JsonElement current, JsonElement previous) {
        if (current == null) {
            return previous;
        }
        if (previous == null) {
            return current;
        }
        if (current.isJsonObject() && previous.isJsonObject()) {
            JsonObject result = GsonCompat.deepCopy(current).getAsJsonObject();
            for (Map.Entry entry : previous.getAsJsonObject().entrySet()) {
                String key = (String)entry.getKey();
                JsonElement previousValue = (JsonElement)entry.getValue();
                JsonElement currentValue = result.get(key);
                if (currentValue != null && (!currentValue.isJsonObject() || !previousValue.isJsonObject())) continue;
                result.add(key, this.merge(currentValue, previousValue));
            }
            return result;
        }
        return current;
    }
}

