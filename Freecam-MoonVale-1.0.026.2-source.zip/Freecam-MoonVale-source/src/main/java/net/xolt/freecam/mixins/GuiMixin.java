package net.xolt.freecam.mixins;

import net.minecraft.client.gui.Gui;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={Gui.class})
public class GuiMixin {
    public GuiMixin() {
        super();
    }
}

