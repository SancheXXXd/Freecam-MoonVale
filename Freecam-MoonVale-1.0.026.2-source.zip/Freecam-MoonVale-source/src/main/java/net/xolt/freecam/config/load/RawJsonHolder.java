package net.xolt.freecam.config.load;

import com.google.gson.JsonObject;
import org.jetbrains.annotations.Nullable;

public interface RawJsonHolder {
    public void setRawJson(JsonObject var1);

    @Nullable
    public JsonObject getRawJson();
}

