package net.xolt.freecam.mixins;

import net.minecraft.client.player.LocalPlayer;
import net.xolt.freecam.Freecam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LocalPlayer.class})
public class LocalPlayerMixin {
    public LocalPlayerMixin() {
        super();
    }

    @Inject(method={"isControlledCamera"}, at={@At(value="HEAD")}, cancellable=true)
    private void onIsCamera(CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.isEnabled() && this.freecam$this() == Freecam.MC.player) {
            cir.setReturnValue((Object)true);
        }
    }

    @Inject(method={"getViewXRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetViewXRot(float partialTick, CallbackInfoReturnable<Float> cir) {
        if (Freecam.isEnabled()) {
            cir.setReturnValue((Object)Float.valueOf(Freecam.getFreeCamera().getViewXRot(partialTick)));
        }
    }

    @Inject(method={"getViewYRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetViewYRot(float partialTick, CallbackInfoReturnable<Float> cir) {
        if (Freecam.isEnabled()) {
            cir.setReturnValue((Object)Float.valueOf(Freecam.getFreeCamera().getViewYRot(partialTick)));
        }
    }

    @Unique
    private LocalPlayer freecam$this() {
        return (LocalPlayer)this;
    }
}

