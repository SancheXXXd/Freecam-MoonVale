package net.xolt.freecam.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.state.LightmapRenderState;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.ModConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={Lightmap.class})
public class FullBrightMixin {
    public FullBrightMixin() {
        super();
    }

    @WrapOperation(method={"render"}, at={@At(value="FIELD", target="Lnet/minecraft/client/renderer/state/LightmapRenderState;brightness:F")})
    private float getBrightness(LightmapRenderState instance, Operation<Float> original) {
        if (Freecam.isEnabled() && ModConfig.get().isFullBrightEnabled()) {
            return 16.0f;
        }
        return ((Float)original.call(new Object[]{instance})).floatValue();
    }
}

