package net.xolt.freecam.config;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.gui.ConfigScreenProvider;
import net.xolt.freecam.config.keys.FreecamKeyMapping;
import net.xolt.freecam.config.keys.FreecamKeyMappingBuilder;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum ModBindings {
    KEY_TOGGLE((Supplier<FreecamKeyMapping>)((Supplier)() -> FreecamKeyMappingBuilder.builder("toggle").action(Freecam::toggle).holdAction(Freecam::activateTripodHandler).defaultKey(293).build())),
    KEY_TRIPOD_RESET((Supplier<FreecamKeyMapping>)((Supplier)() -> FreecamKeyMappingBuilder.builder("tripod.reset").holdAction(Freecam::resetTripodHandler).build())),
    KEY_CONFIG_GUI((Supplier<FreecamKeyMapping>)((Supplier)() -> FreecamKeyMappingBuilder.builder("config.open").action(ConfigScreenProvider.provider()::openConfigScreen).build()));

    private static final Logger LOGGER;
    private final Supplier<FreecamKeyMapping> lazyMapping;

    private ModBindings(Supplier<FreecamKeyMapping> mappingSupplier) {
        this.lazyMapping = Suppliers.memoize(mappingSupplier);
    }

    public FreecamKeyMapping get() {
        return (FreecamKeyMapping)this.lazyMapping.get();
    }

    public static void forEach(@NotNull Consumer<FreecamKeyMapping> action) {
        Objects.requireNonNull(action);
        ModBindings.iterator().forEachRemaining(action);
    }

    @NotNull
    public static Iterator<FreecamKeyMapping> iterator() {
        return ModBindings.stream().iterator();
    }

    @NotNull
    public static Spliterator<FreecamKeyMapping> spliterator() {
        return ModBindings.stream().spliterator();
    }

    @NotNull
    public static Stream<FreecamKeyMapping> stream() {
        return Arrays.stream(ModBindings.values()).map(ModBindings::get);
    }

    private static Logger logger() {
        return LOGGER;
    }

    static {
        LOGGER = LoggerFactory.getLogger(ModBindings.class);
    }
}

