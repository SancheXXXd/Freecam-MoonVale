package net.xolt.freecam.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets={"net.xolt.freecam.util.FreeCamera"}, remap=false)
public abstract class SquareBoundaryMixin {
    private static final double LIMIT = 32.0;
    private static final double SOFT_START = 26.0;
    private static final double SOFT_WIDTH = 6.0;
    private static final double BOUNDARY_EPSILON = 1.0E-4;

    public SquareBoundaryMixin() {
        super();
    }

    @Accessor(value="boundaryContactNormal", remap=false)
    protected abstract Vector3f freecam$getBoundaryContactNormal();

    @Accessor(value="boundaryGlow", remap=false)
    protected abstract float freecam$getBoundaryGlow();

    @Accessor(value="boundaryGlow", remap=false)
    protected abstract void freecam$setBoundaryGlow(float var1);

    @Inject(method={"applyBoundaryResistance"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void freecam$applySquareResistance(CallbackInfo ci) {
        LocalPlayer player = Minecraft.getInstance().player;
        Entity camera = (Entity)this;
        if (player != null) {
            double dx = camera.getX() - player.getX();
            double dy = camera.getY() - player.getEyeY();
            double dz = camera.getZ() - player.getZ();
            Vec3 velocity = camera.getDeltaMovement();
            double vx = SquareBoundaryMixin.resistAxis(dx, velocity.x);
            double vy = SquareBoundaryMixin.resistAxis(dy, velocity.y);
            double vz = SquareBoundaryMixin.resistAxis(dz, velocity.z);
            boolean lockX = SquareBoundaryMixin.isLockedOutward(dx, velocity.x);
            boolean lockY = SquareBoundaryMixin.isLockedOutward(dy, velocity.y);
            boolean lockZ = SquareBoundaryMixin.isLockedOutward(dz, velocity.z);
            if (lockX || lockY || lockZ) {
                double x = lockX ? player.getX() + Math.copySign(31.9999, dx) : camera.getX();
                double y = lockY ? player.getEyeY() + Math.copySign(31.9999, dy) : camera.getY();
                double z = lockZ ? player.getZ() + Math.copySign(31.9999, dz) : camera.getZ();
                camera.snapTo(x, y, z, camera.getYRot(), camera.getXRot());
                vx = lockX ? 0.0 : vx;
                vy = lockY ? 0.0 : vy;
                vz = lockZ ? 0.0 : vz;
                camera.setDeltaMovement(new Vec3(vx, vy, vz));
                SquareBoundaryMixin.syncPreviousPosition(camera);
            } else if (vx != velocity.x || vy != velocity.y || vz != velocity.z) {
                camera.setDeltaMovement(new Vec3(vx, vy, vz));
            }
            this.updateContactNormal(dx, dy, dz);
            SquareBoundaryMixin.syncPreviousPositionIfLocked(camera, dx, dy, dz);
        }
        ci.cancel();
    }

    @Inject(method={"enforcePlayerRadius"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void freecam$enforceSquareBoundary(CallbackInfo ci) {
        LocalPlayer player = Minecraft.getInstance().player;
        Entity camera = (Entity)this;
        if (player != null) {
            boolean hitZ;
            double x = camera.getX();
            double y = camera.getY();
            double z = camera.getZ();
            double clampedX = SquareBoundaryMixin.clamp(x, player.getX() - 32.0, player.getX() + 32.0);
            double clampedY = SquareBoundaryMixin.clamp(y, player.getEyeY() - 32.0, player.getEyeY() + 32.0);
            double clampedZ = SquareBoundaryMixin.clamp(z, player.getZ() - 32.0, player.getZ() + 32.0);
            boolean hitX = clampedX != x;
            boolean hitY = clampedY != y;
            boolean bl = hitZ = clampedZ != z;
            if (hitX || hitY || hitZ) {
                Vec3 velocity = camera.getDeltaMovement();
                camera.snapTo(clampedX, clampedY, clampedZ, camera.getYRot(), camera.getXRot());
                camera.setDeltaMovement(new Vec3(hitX ? 0.0 : velocity.x, hitY ? 0.0 : velocity.y, hitZ ? 0.0 : velocity.z));
                this.updateContactNormal(clampedX - player.getX(), clampedY - player.getEyeY(), clampedZ - player.getZ());
                SquareBoundaryMixin.syncPreviousPosition(camera);
            }
        }
        ci.cancel();
    }

    @Inject(method={"updateBoundaryGlow"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private void freecam$updateSquareBoundaryGlow(CallbackInfo ci) {
        LocalPlayer player = Minecraft.getInstance().player;
        Entity camera = (Entity)this;
        if (player == null) {
            this.freecam$setBoundaryGlow(0.0f);
        } else {
            double dx = camera.getX() - player.getX();
            double dy = camera.getY() - player.getEyeY();
            double dz = camera.getZ() - player.getZ();
            double axisDistance = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
            float target = (float)SquareBoundaryMixin.clamp((axisDistance - 26.0) / 6.0, 0.0, 1.0);
            float glow = this.freecam$getBoundaryGlow();
            this.freecam$setBoundaryGlow(glow + (target - glow) * 0.18f);
            this.updateContactNormal(dx, dy, dz);
        }
        ci.cancel();
    }

    private static boolean isLockedOutward(double offset, double velocity) {
        return Math.abs(offset) >= 31.9999 && offset != 0.0 && velocity * Math.copySign(1.0, offset) > 0.0;
    }

    private static double resistAxis(double offset, double velocity) {
        double distance = Math.abs(offset);
        if (distance == 0.0) {
            return velocity;
        }
        double direction = Math.copySign(1.0, offset);
        double outward = velocity * direction;
        double pressure = SquareBoundaryMixin.clamp((distance - 26.0) / 6.0, 0.0, 1.0);
        if (outward <= 0.0) {
            return velocity;
        }
        double damping = pressure * pressure * (3.0 - 2.0 * pressure);
        double dampedOutward = outward * (1.0 - damping);
        double remainingDistance = Math.max(0.0, 32.0 - distance - 1.0E-4);
        double allowedOutward = Math.min(dampedOutward, remainingDistance);
        return direction * allowedOutward;
    }

    private static void syncPreviousPositionIfLocked(Entity camera, double dx, double dy, double dz) {
        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) >= 31.9999) {
            SquareBoundaryMixin.syncPreviousPosition(camera);
        }
    }

    private static void syncPreviousPosition(Entity entity) {
    }

    private void updateContactNormal(double dx, double dy, double dz) {
        double ax = Math.abs(dx);
        double ay = Math.abs(dy);
        double az = Math.abs(dz);
        if (ax >= ay && ax >= az) {
            this.freecam$getBoundaryContactNormal().set(Math.copySign(1.0f, (float)dx), 0.0f, 0.0f);
        } else if (ay >= az) {
            this.freecam$getBoundaryContactNormal().set(0.0f, Math.copySign(1.0f, (float)dy), 0.0f);
        } else {
            this.freecam$getBoundaryContactNormal().set(0.0f, 0.0f, Math.copySign(1.0f, (float)dz));
        }
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}

