package net.xolt.freecam.mixins;

import net.minecraft.client.multiplayer.ClientPacketListener;
import net.xolt.freecam.Freecam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ClientPacketListener.class})
public class ClientPacketListenerMixin {
    public ClientPacketListenerMixin() {
        super();
    }

    @Inject(method={"handleRespawn"}, at={@At(value="TAIL")})
    private void onPlayerRespawn(CallbackInfo ci) {
        if (Freecam.isEnabled()) {
            Freecam.toggle();
        }
    }
}

