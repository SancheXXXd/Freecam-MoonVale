package net.xolt.freecam;

import java.util.Collection;
import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.xolt.freecam.util.MultiServiceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface ModPlatform {
    public boolean isModLoaded(String var1);

    public static ModPlatform get() {
        return Holder.INSTANCE;
    }

    public static final class Holder {
        private static final Logger LOGGER = LoggerFactory.getLogger((String)"Freecam/ModPlatform");
        private static final ModPlatform INSTANCE;

        private Holder() {
            super();
        }

        static {
            Collection<ServiceLoader.Provider<ModPlatform>> providers = MultiServiceLoader.get(ModPlatform.class);
            LOGGER.debug("Loaded: {}", (Object)providers.stream().map(provider -> provider.type().getSimpleName()).collect(Collectors.joining(", ")));
            INSTANCE = providers.stream().findFirst().map(provider -> {
                LOGGER.debug("Using {}", (Object)provider.type().getSimpleName());
                return (ModPlatform)provider.get();
            }).orElseThrow(() -> {
                String msg = "No provider found";
                LOGGER.error(msg);
                return new IllegalStateException(msg);
            });
        }
    }
}

