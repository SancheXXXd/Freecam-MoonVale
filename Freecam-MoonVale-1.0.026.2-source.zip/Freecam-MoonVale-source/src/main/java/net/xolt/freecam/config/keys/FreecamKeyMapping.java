package net.xolt.freecam.config.keys;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.function.Consumer;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import net.xolt.freecam.config.keys.Tickable;

public class FreecamKeyMapping
extends KeyMapping
implements Tickable {
    private static final KeyMapping.Category FREECAM_CATEGORY = KeyMapping.Category.register((Identifier)Identifier.fromNamespaceAndPath((String)"freecam", (String)"controls"));
    private final Consumer<FreecamKeyMapping> onTick;

    protected FreecamKeyMapping(String translationKey, InputConstants.Type type, int code) {
        this(translationKey, type, code, null);
    }

    FreecamKeyMapping(String translationKey, InputConstants.Type type, int code, Consumer<FreecamKeyMapping> onTick) {
        super("key.freecam." + translationKey, type, code, FREECAM_CATEGORY);
        this.onTick = onTick;
    }

    @Override
    public void tick() {
        this.onTick.accept(this);
    }

    public void reset() {
        while (this.consumeClick()) {
        }
    }
}

