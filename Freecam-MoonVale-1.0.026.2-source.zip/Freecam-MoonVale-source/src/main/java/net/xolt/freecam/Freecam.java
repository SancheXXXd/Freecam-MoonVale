package net.xolt.freecam;

import java.util.Optional;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.level.ChunkPos;
import net.xolt.freecam.config.ModBindings;
import net.xolt.freecam.config.ModConfig;
import net.xolt.freecam.config.keys.Tickable;
import net.xolt.freecam.tripod.TripodRegistry;
import net.xolt.freecam.tripod.TripodSlot;
import net.xolt.freecam.util.FreeCamera;
import net.xolt.freecam.util.FreecamPosition;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public class Freecam {
    public static final Minecraft MC = Minecraft.getInstance();
    public static final String MOD_ID = "freecam";
    private static volatile boolean freecamEnabled = false;
    private static volatile boolean tripodEnabled = false;
    private static boolean disableNextTick = false;
    private static final TripodRegistry tripods = new TripodRegistry();
    private static TripodSlot activeTripod = TripodSlot.NONE;
    private static FreeCamera freeCamera;
    private static CameraType rememberedF5;

    public Freecam() {
        super();
    }

    @ApiStatus.Internal
    public static void preTick(Minecraft mc) {
        if (disableNextTick && Freecam.isEnabled()) {
            Freecam.toggle();
        }
        disableNextTick = false;
        if (Freecam.isEnabled() && mc.player != null && mc.player.input instanceof KeyboardInput) {
            ClientInput input = new ClientInput();
            Input keyPresses = mc.player.input.keyPresses;
            input.keyPresses = new Input(false, false, false, false, false, keyPresses.shift(), false);
            mc.player.input = input;
        }
    }

    @ApiStatus.Internal
    public static void postTick(Minecraft mc) {
        ModBindings.forEach(Tickable::tick);
    }

    @ApiStatus.Internal
    public static void onDisconnect() {
        if (Freecam.isEnabled()) {
            Freecam.toggle();
        }
        tripods.clear();
    }

    @ApiStatus.Internal
    public static boolean activateTripodHandler() {
        boolean activated = false;
        for (KeyMapping combo : Freecam.MC.options.keyHotbarSlots) {
            while (combo.consumeClick()) {
                Freecam.toggleTripod(TripodSlot.ofKeyCode(combo.getDefaultKey().getValue()));
                activated = true;
            }
        }
        return activated;
    }

    @ApiStatus.Internal
    public static boolean resetTripodHandler() {
        boolean reset = false;
        for (KeyMapping key : Freecam.MC.options.keyHotbarSlots) {
            while (key.consumeClick()) {
                Freecam.resetCamera(TripodSlot.ofKeyCode(key.getDefaultKey().getValue()));
                reset = true;
            }
        }
        return reset;
    }

    @ApiStatus.AvailableSince(value="0.3.1")
    public static void toggle() {
        if (tripodEnabled) {
            Freecam.toggleTripod(activeTripod);
            return;
        }
        if (freecamEnabled) {
            Freecam.onDisableFreecam();
        } else {
            Freecam.onEnableFreecam();
        }
        boolean bl = freecamEnabled = !freecamEnabled;
        if (!freecamEnabled) {
            Freecam.onDisabled();
        }
    }

    private static void toggleTripod(TripodSlot tripod) {
        if (tripod == TripodSlot.NONE) {
            return;
        }
        if (tripodEnabled) {
            if (activeTripod == tripod) {
                Freecam.onDisableTripod();
                tripodEnabled = false;
            } else {
                Freecam.onDisableTripod();
                Freecam.onEnableTripod(tripod);
            }
        } else {
            if (freecamEnabled) {
                Freecam.toggle();
            }
            Freecam.onEnableTripod(tripod);
            tripodEnabled = true;
        }
        if (!tripodEnabled) {
            Freecam.onDisabled();
        }
    }

    private static void onEnableTripod(TripodSlot tripod) {
        Freecam.onEnable();
        FreecamPosition position = tripods.get(tripod);
        boolean chunkLoaded = false;
        if (position != null) {
            ChunkPos chunkPos = position.getChunkPos();
            chunkLoaded = Freecam.MC.level.getChunkSource().hasChunk(chunkPos.x(), chunkPos.z());
        }
        if (!chunkLoaded) {
            Freecam.resetCamera(tripod);
            position = null;
        }
        freeCamera = new FreeCamera(-420 - tripod.ordinal());
        if (position == null) {
            Freecam.moveToPlayer();
        } else {
            Freecam.moveToPosition(position);
        }
        freeCamera.spawn();
        MC.setCameraEntity((Entity)freeCamera);
        activeTripod = tripod;
        if (ModConfig.get().shouldNotifyTripod()) {
            Freecam.sendOverlayMessage((Component)Component.translatable((String)"freecam.msg.tripod.open", (Object[])new Object[]{tripod}));
        }
    }

    private static void onDisableTripod() {
        tripods.put(activeTripod, new FreecamPosition((Entity)freeCamera));
        Freecam.onDisable();
        if (Freecam.MC.player != null && ModConfig.get().shouldNotifyTripod()) {
            Freecam.sendOverlayMessage((Component)Component.translatable((String)"freecam.msg.tripod.close", (Object[])new Object[]{activeTripod}));
        }
        activeTripod = TripodSlot.NONE;
    }

    private static void onEnableFreecam() {
        Freecam.onEnable();
        freeCamera = new FreeCamera(-420);
        Freecam.moveToPlayer();
        freeCamera.spawn();
        MC.setCameraEntity((Entity)freeCamera);
        if (ModConfig.get().shouldNotifyFreecam()) {
            Freecam.sendOverlayMessage((Component)Component.translatable((String)"freecam.msg.enabled"));
        }
    }

    private static void onDisableFreecam() {
        Freecam.onDisable();
        if (Freecam.MC.player != null && ModConfig.get().shouldNotifyFreecam()) {
            Freecam.sendOverlayMessage((Component)Component.translatable((String)"freecam.msg.disabled"));
        }
    }

    private static void onEnable() {
        Freecam.MC.smartCull = false;
        rememberedF5 = Freecam.MC.options.getCameraType();
        if (Freecam.MC.gameRenderer.mainCamera().isDetached()) {
            Freecam.MC.options.setCameraType(CameraType.FIRST_PERSON);
        }
    }

    private static void onDisable() {
        Freecam.MC.smartCull = true;
        MC.setCameraEntity((Entity)Freecam.MC.player);
        freeCamera.despawn();
        Freecam.freeCamera.input = new ClientInput();
        freeCamera = null;
        if (Freecam.MC.player != null) {
            Freecam.MC.player.input = new KeyboardInput(Freecam.MC.options);
        }
    }

    private static void onDisabled() {
        if (rememberedF5 != null) {
            Freecam.MC.options.setCameraType(rememberedF5);
        }
    }

    private static void resetCamera(TripodSlot tripod) {
        if (tripodEnabled && activeTripod != TripodSlot.NONE && activeTripod == tripod && freeCamera != null) {
            Freecam.moveToPlayer();
        } else {
            tripods.put(tripod, null);
        }
        if (ModConfig.get().shouldNotifyTripod()) {
            Freecam.sendOverlayMessage((Component)Component.translatable((String)"freecam.msg.tripod.reset", (Object[])new Object[]{tripod}));
        }
    }

    private static void sendOverlayMessage(Component message) {
        Optional.ofNullable(Freecam.MC.player).ifPresent(player -> player.sendOverlayMessage(message));
    }

    @ApiStatus.Experimental
    @ApiStatus.AvailableSince(value="1.2.3")
    public static void moveToEntity(@Nullable Entity entity) {
        if (freeCamera == null) {
            return;
        }
        if (entity == null) {
            Freecam.moveToPlayer();
            return;
        }
        freeCamera.copyPosition(entity);
    }

    @ApiStatus.Experimental
    @ApiStatus.AvailableSince(value="1.2.3")
    public static void moveToPosition(@Nullable FreecamPosition position) {
        if (freeCamera == null) {
            return;
        }
        if (position == null) {
            Freecam.moveToPlayer();
            return;
        }
        freeCamera.applyPosition(position);
        freeCamera.enforcePlayerRadius();
    }

    @ApiStatus.Experimental
    @ApiStatus.AvailableSince(value="1.2.3")
    public static void moveToPlayer() {
        if (freeCamera == null) {
            return;
        }
        freeCamera.copyPosition((Entity)Freecam.MC.player);
        freeCamera.applyPerspective(ModConfig.get().getInitialPerspective());
        freeCamera.enforcePlayerRadius();
    }

    @ApiStatus.AvailableSince(value="0.4.0")
    public static FreeCamera getFreeCamera() {
        return freeCamera;
    }

    @ApiStatus.AvailableSince(value="1.2.3")
    public static void disableNextTick() {
        disableNextTick = true;
    }

    @ApiStatus.AvailableSince(value="0.2.2")
    public static boolean isEnabled() {
        return freecamEnabled || tripodEnabled;
    }

    static {
        rememberedF5 = null;
    }
}

