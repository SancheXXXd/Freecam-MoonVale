package net.xolt.freecam.config.load;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.xolt.freecam.config.load.ConfigLoader;
import net.xolt.freecam.config.load.ConfigSerializer;

public class BasicConfigLoader<T, S>
implements ConfigLoader<T> {
    private final ConfigSerializer<S> serializer;
    private final Class<T> configClass;
    private final Path filepath;

    public BasicConfigLoader(ConfigSerializer<S> serializer, Class<T> configClass, Path filepath) {
        super();
        this.serializer = serializer;
        this.configClass = configClass;
        this.filepath = filepath;
    }

    @Override
    public T read() throws Exception {
        S data;
        if (!Files.exists(this.filepath, new LinkOption[0])) {
            return this.configClass.getConstructor(new Class[0]).newInstance(new Object[0]);
        }
        try (BufferedReader reader = Files.newBufferedReader(this.filepath);){
            data = this.serializer.parse(reader);
        }
        return this.serializer.deserialize(data, this.configClass);
    }

    @Override
    public void write(T config) throws Exception {
        S data = this.serializer.serialize(config);
        Files.createDirectories(this.filepath.getParent(), new FileAttribute[0]);
        try (BufferedWriter writer = Files.newBufferedWriter(this.filepath, new OpenOption[0]);){
            this.serializer.write(data, writer);
        }
    }

    @Override
    public Path getFilepath() {
        return this.filepath;
    }
}

