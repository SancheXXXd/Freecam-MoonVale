package net.xolt.freecam.config.load;

import java.nio.file.Path;

public interface ConfigLoader<T> {
    public void write(T var1) throws Exception;

    public T read() throws Exception;

    public Path getFilepath();
}

