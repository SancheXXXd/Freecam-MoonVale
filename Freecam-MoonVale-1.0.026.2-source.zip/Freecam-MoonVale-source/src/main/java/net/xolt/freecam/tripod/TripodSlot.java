package net.xolt.freecam.tripod;

public enum TripodSlot {
    NONE,
    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE;

    public static final int MIN = 1;
    public static final int MAX;

    static {
        MAX = TripodSlot.values().length - 1;
    }

    public String toString() {
        return this == NONE ? "None" : "#%d".formatted(this.ordinal());
    }

    public static boolean inRange(int number) {
        return number >= 1 && number <= MAX;
    }

    public static TripodSlot ofKeyCode(int keyCode) {
        int number = keyCode - 48;
        return TripodSlot.inRange(number) ? TripodSlot.values()[number] : NONE;
    }

    public static TripodSlot valueOf(String string) {
        return Enum.valueOf(TripodSlot.class, string);
    }
}

