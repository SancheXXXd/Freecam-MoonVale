package net.xolt.freecam.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.phys.Vec3;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.util.FreeCamera;
import org.joml.Vector3f;

public final class BoundaryRenderer {
    private static final double RADIUS = 32.0;
    private static final int LATITUDE_LINES = 9;
    private static final int LONGITUDE_LINES = 16;
    private static final int SEGMENTS = 40;
    private static final int COLOR_A_R = 57;
    private static final int COLOR_A_G = 125;
    private static final int COLOR_A_B = 236;
    private static final int COLOR_B_R = 169;
    private static final int COLOR_B_G = 208;
    private static final int COLOR_B_B = 252;

    private BoundaryRenderer() {
        super();
    }

    public static void submit(SubmitNodeCollector collector, CameraRenderState cameraState) {
        if (!Freecam.isEnabled() || Freecam.MC.player == null) {
            return;
        }
        FreeCamera camera = Freecam.getFreeCamera();
        if (camera == null || camera.getBoundaryGlow() < 0.01f || cameraState.pos == null) {
            return;
        }
        Vec3 center = Freecam.MC.player.getEyePosition();
        Vector3f contactNormal = camera.getBoundaryContactNormal();
        float glow = camera.getBoundaryGlow();
        float time = (float)(Freecam.MC.level == null ? 0L : Freecam.MC.level.getGameTime()) * 0.08f;
        PoseStack matrices = new PoseStack();
        matrices.translate(center.x - cameraState.pos.x, center.y - cameraState.pos.y, center.z - cameraState.pos.z);
        collector.submitCustomGeometry(matrices, RenderTypes.linesTranslucent(), (pose, consumer) -> BoundaryRenderer.drawBoundary(pose, consumer, contactNormal, glow, time));
    }

    private static void drawBoundary(PoseStack.Pose pose, VertexConsumer consumer, Vector3f contactNormal, float glow, float time) {
        consumer.setLineWidth(2.0f);
        for (int latitude = 1; latitude < 9; ++latitude) {
            double phi = -1.5707963267948966 + Math.PI * (double)latitude / 9.0;
            BoundaryRenderer.drawRing(pose, consumer, Math.cos(phi), Math.sin(phi), contactNormal, glow, time);
        }
        for (int longitude = 0; longitude < 16; ++longitude) {
            double theta = Math.PI * 2 * (double)longitude / 16.0;
            BoundaryRenderer.drawMeridian(pose, consumer, theta, contactNormal, glow, time);
        }
    }

    private static void drawRing(PoseStack.Pose pose, VertexConsumer consumer, double ringRadius, double y, Vector3f contactNormal, float glow, float time) {
        for (int i = 0; i < 40; ++i) {
            double a = Math.PI * 2 * (double)i / 40.0;
            double b = Math.PI * 2 * (double)(i + 1) / 40.0;
            BoundaryRenderer.drawSegment(pose, consumer, 32.0 * ringRadius * Math.cos(a), 32.0 * y, 32.0 * ringRadius * Math.sin(a), 32.0 * ringRadius * Math.cos(b), 32.0 * y, 32.0 * ringRadius * Math.sin(b), contactNormal, glow, time);
        }
    }

    private static void drawMeridian(PoseStack.Pose pose, VertexConsumer consumer, double theta, Vector3f contactNormal, float glow, float time) {
        for (int i = 0; i < 40; ++i) {
            double a = -1.5707963267948966 + Math.PI * (double)i / 40.0;
            double b = -1.5707963267948966 + Math.PI * (double)(i + 1) / 40.0;
            BoundaryRenderer.drawSegment(pose, consumer, 32.0 * Math.cos(a) * Math.cos(theta), 32.0 * Math.sin(a), 32.0 * Math.cos(a) * Math.sin(theta), 32.0 * Math.cos(b) * Math.cos(theta), 32.0 * Math.sin(b), 32.0 * Math.cos(b) * Math.sin(theta), contactNormal, glow, time);
        }
    }

    private static void drawSegment(PoseStack.Pose pose, VertexConsumer consumer, double x1, double y1, double z1, double x2, double y2, double z2, Vector3f contactNormal, float glow, float time) {
        BoundaryRenderer.setVertex(pose, consumer, x1, y1, z1, contactNormal, glow, time);
        BoundaryRenderer.setVertex(pose, consumer, x2, y2, z2, contactNormal, glow, time);
    }

    private static void setVertex(PoseStack.Pose pose, VertexConsumer consumer, double x, double y, double z, Vector3f contactNormal, float glow, float time) {
        double length = Math.sqrt(x * x + y * y + z * z);
        double nx = x / length;
        double ny = y / length;
        double nz = z / length;
        double dot = Math.max(0.0, nx * (double)contactNormal.x() + ny * (double)contactNormal.y() + nz * (double)contactNormal.z());
        double angularWave = 0.5 + 0.5 * Math.cos((1.0 - dot) * Math.PI * 2.0 - (double)time);
        float colorFactor = (float)Math.min(1.0, 0.15 + 0.85 * angularWave);
        float alpha = Math.min(0.9f, glow * (0.22f + 0.68f * colorFactor));
        int r = BoundaryRenderer.mix(57, 169, colorFactor);
        int g = BoundaryRenderer.mix(125, 208, colorFactor);
        int b = BoundaryRenderer.mix(236, 252, colorFactor);
        consumer.addVertex(pose, (float)x, (float)y, (float)z).setColor(r, g, b, (int)(alpha * 255.0f));
    }

    private static int mix(int a, int b, float factor) {
        return Math.round((float)a + (float)(b - a) * factor);
    }
}

