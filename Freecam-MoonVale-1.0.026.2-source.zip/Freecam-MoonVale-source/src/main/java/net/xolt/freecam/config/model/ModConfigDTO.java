package net.xolt.freecam.config.model;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.xolt.freecam.config.load.RawJsonHolder;
import net.xolt.freecam.config.model.FlightMode;
import net.xolt.freecam.config.model.Perspective;
import org.jetbrains.annotations.Nullable;

public class ModConfigDTO
implements RawJsonHolder {
    @Nullable
    private transient JsonObject rawJson;
    public MovementConfig movement = new MovementConfig();
    public CollisionConfig collision = new CollisionConfig();
    public VisualConfig visual = new VisualConfig();
    public UtilityConfig utility = new UtilityConfig();
    public NotificationConfig notification = new NotificationConfig();

    public ModConfigDTO() {
        super();
    }

    @Override
    public void setRawJson(@Nullable JsonObject rawJson) {
        this.rawJson = rawJson;
    }

    @Override
    @Nullable
    public JsonObject getRawJson() {
        return this.rawJson;
    }

    public static class MovementConfig {
        public FlightMode flightMode = FlightMode.DEFAULT;
        public double horizontalSpeed = 1.0;
        public double verticalSpeed = 1.0;

        public MovementConfig() {
            super();
        }
    }

    public static class CollisionConfig {
        public boolean ignoreTransparent = false;
        public boolean ignoreOpenable = false;
        public boolean ignoreCustom = false;
        public CollisionWhitelist whitelist = new CollisionWhitelist();
        public boolean ignoreAll = true;
        public boolean alwaysCheck = false;

        public CollisionConfig() {
            super();
        }

        public static class CollisionWhitelist {
            public List<String> ids = new ArrayList<String>();
            public List<String> patterns = new ArrayList<String>();

            public CollisionWhitelist() {
                super();
            }
        }
    }

    public static class VisualConfig {
        public Perspective perspective = Perspective.INSIDE;
        public boolean showPlayer = true;
        public boolean showHand = false;
        public boolean fullBright = false;

        public VisualConfig() {
            super();
        }
    }

    public static class UtilityConfig {
        public boolean disableOnDamage = true;

        public UtilityConfig() {
            super();
        }
    }

    public static class NotificationConfig {
        public boolean notifyFreecam = true;
        public boolean notifyTripod = true;

        public NotificationConfig() {
            super();
        }
    }
}

