package net.xolt.freecam.util;

import java.util.Collection;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultiServiceLoader<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MultiServiceLoader.class);
    private static final Map<Class<?>, MultiServiceLoader<?>> SERVICE_LOADERS = new ConcurrentHashMap();
    private final Class<T> serviceClass;
    private final Map<ClassLoader, Collection<ServiceLoader.Provider<T>>> providers = new ConcurrentHashMap<ClassLoader, Collection<ServiceLoader.Provider<T>>>();

    private MultiServiceLoader(Class<T> serviceClass) {
        super();
        this.serviceClass = serviceClass;
    }

    public static <T> Collection<ServiceLoader.Provider<T>> get(Class<T> serviceClass) {
        return MultiServiceLoader.getServiceLoader(serviceClass).getProviders();
    }

    private static <T> MultiServiceLoader<T> getServiceLoader(Class<T> serviceClass) {
        return SERVICE_LOADERS.computeIfAbsent(serviceClass, MultiServiceLoader::new);
    }

    private Collection<ServiceLoader.Provider<T>> getProviders() {
        return this.providers.computeIfAbsent(Thread.currentThread().getContextClassLoader(), this::loadProviders);
    }

    private Collection<ServiceLoader.Provider<T>> loadProviders(ClassLoader classLoader) {
        String name = this.serviceClass.getSimpleName();
        LOGGER.debug("Loading service providers for {}", (Object)name);
        return ServiceLoader.load(this.serviceClass, classLoader).stream().toList();
    }
}

