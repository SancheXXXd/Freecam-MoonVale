package net.xolt.freecam.config.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.xolt.freecam.config.controller.ConfigController;
import net.xolt.freecam.config.load.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BasicConfigController<T>
implements ConfigController<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(BasicConfigController.class);
    private final ConfigLoader<T> loader;
    private final List<Runnable> listeners = new ArrayList<Runnable>();
    private final T defaults;
    private final Supplier<T> defaultSupplier;
    private T config;

    public BasicConfigController(ConfigLoader<T> loader, Supplier<T> defaultSupplier) {
        super();
        this.loader = loader;
        this.defaults = defaultSupplier.get();
        this.defaultSupplier = defaultSupplier;
    }

    @Override
    public T getConfig() {
        if (this.config == null) {
            throw new IllegalStateException("Freecam config used before load");
        }
        return this.config;
    }

    @Override
    public T getDefaults() {
        return this.defaults;
    }

    @Override
    public void load() {
        try {
            this.config = this.loader.read();
        }
        catch (Exception e) {
            LOGGER.error("Failed to load config, using defaults", (Throwable)e);
            this.config = this.defaultSupplier.get();
        }
        this.listeners.forEach(Runnable::run);
    }

    @Override
    public void save() {
        T config = this.config;
        if (config == null) {
            return;
        }
        try {
            this.loader.write(config);
        }
        catch (Exception e) {
            LOGGER.error("Failed to save config", (Throwable)e);
        }
        this.listeners.forEach(Runnable::run);
    }

    @Override
    public void registerListener(Runnable listener) {
        this.listeners.add(listener);
    }
}

