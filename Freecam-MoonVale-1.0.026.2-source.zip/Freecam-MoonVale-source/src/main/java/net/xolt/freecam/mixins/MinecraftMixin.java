package net.xolt.freecam.mixins;

import net.minecraft.client.Minecraft;
import net.xolt.freecam.Freecam;
import net.xolt.freecam.config.ModBindings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Minecraft.class})
public class MinecraftMixin {
    public MinecraftMixin() {
        super();
    }

    @Inject(method={"startAttack"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDoAttack(CallbackInfoReturnable<Boolean> ci) {
        if (Freecam.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method={"pickBlockOrEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void onDoItemPick(CallbackInfo ci) {
        if (Freecam.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method={"continueAttack"}, at={@At(value="HEAD")}, cancellable=true)
    private void onHandleBlockBreaking(CallbackInfo ci) {
        if (Freecam.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method={"handleKeybinds"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/KeyMapping;consumeClick()Z", ordinal=2)}, cancellable=true)
    private void onHandleInputEvents(CallbackInfo ci) {
        if (ModBindings.KEY_TOGGLE.get().isDown() || ModBindings.KEY_TRIPOD_RESET.get().isDown()) {
            ci.cancel();
        }
    }

    @Inject(method={"disconnect*"}, at={@At(value="HEAD")})
    private void onDisconnect(CallbackInfo ci) {
        Freecam.onDisconnect();
    }
}

