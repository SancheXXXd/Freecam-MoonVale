package net.xolt.freecam.config.gui;

import net.minecraft.client.gui.screens.Screen;
import net.xolt.freecam.config.gui.ConfigScreenProvider;
import net.xolt.freecam.config.gui.FallbackConfigScreen;

final class FallbackConfigScreenProvider
implements ConfigScreenProvider {
    FallbackConfigScreenProvider() {
        super();
    }

    @Override
    public Screen getConfigScreen(Screen parent) {
        return new FallbackConfigScreen(parent);
    }

    @Override
    public String getName() {
        return "fallback screen";
    }
}

