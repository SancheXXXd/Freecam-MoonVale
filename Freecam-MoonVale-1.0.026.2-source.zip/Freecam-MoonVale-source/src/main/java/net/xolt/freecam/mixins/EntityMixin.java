package net.xolt.freecam.mixins;

import net.minecraft.world.entity.Entity;
import net.xolt.freecam.Freecam;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Entity.class})
public class EntityMixin {
    public EntityMixin() {
        super();
    }

    @Inject(method={"turn"}, at={@At(value="HEAD")}, cancellable=true)
    private void onChangeLookDirection(double rotation, double pitch, CallbackInfo ci) {
        if (Freecam.isEnabled() && this.freecam$this() == Freecam.MC.player) {
            Freecam.getFreeCamera().turn(rotation, pitch);
            ci.cancel();
        }
    }

    @Inject(method={"push(Lnet/minecraft/world/entity/Entity;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPushAwayFrom(Entity entity, CallbackInfo ci) {
        if (Freecam.isEnabled() && (entity == Freecam.getFreeCamera() || this.freecam$this() == Freecam.getFreeCamera())) {
            ci.cancel();
        }
    }

    @Unique
    private Entity freecam$this() {
        return (Entity)this;
    }
}

